/*
 
 Z_OSC - OSC Library for Arduino.
 
 This library seems to work with Arduino firmware 0022.
 
 Copyright 2011, Jérôme Dupraz. All Rights Reserved
 
 Based on the ArdOSC of recotana( http://recotana.com )
 
 Installation
 Z_OSC folder into : ~/Documents/Arduino/libraries/
 
 http://www.arduino.cc/en/Hacking/Libraries
 
 
 -------- License -----------------------------------------------------------
 
 Z_OSC
 
 The MIT License
 
 Copyright © 2011 Jérôme Dupraz
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
 and associated documentation files (the "Software"), to deal in the Software without restriction, 
 including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
 subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included 
 in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
 AND NO INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 
 Except as contained in this notice, the name of Jérôme Dupraz shall not be used in advertising 
 or otherwise to promote the sale, use or other dealings in this Software 
 without prior written authorization from Jérôme Dupraz. 
 
 Thanks "Open Sound Control org"  http://opensoundcontrol.org/ 
 */		

#ifndef Z_OSC_h
#define Z_OSC_h

#include "Z_OSCCommon/Z_OSCcommon.h"
#include "Z_OSCCommon/Z_OSCMessage.h"


#include "Z_OSCCommon/Z_OSCClient.h"
#include "Z_OSCCommon/Z_OSCServer.h"



#endif